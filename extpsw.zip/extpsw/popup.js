const form = document.getElementById("entry-form");
const entriesEl = document.getElementById("entries");
const showPasswordsEl = document.getElementById("show-passwords");
const storageKey = "passwordManager.entries";
const data = [];

function load() {
    try {
        const saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
        if (Array.isArray(saved)) {
            data.length = 0;
            data.push(...saved);
        }
    } catch {}
}

function save() {
    localStorage.setItem(storageKey, JSON.stringify(data));
}

function render() {
    const show = showPasswordsEl.checked;
    entriesEl.innerHTML = "";
    for (const item of data) {
        const li = document.createElement("li");
        li.textContent = `${item.site} — ${item.username} — ${show ? item.password : "••••••"}`;
        entriesEl.appendChild(li);
    }
}

load();
render();

form.addEventListener("submit", (e) => {
    e.preventDefault();
    const site = document.getElementById("site").value.trim();
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value;
    if (!site || !username || !password) return;
    data.push({ site, username, password });
    save();
    form.reset();
    render();
});

showPasswordsEl.addEventListener("change", render);
